# ANIGMA 테스트 제출 코드

## 문제
args를 이용한 파일 입력으로 정수 하나가 입력되는데 그 정수 + 1 한 값을 출력하시오

## 예제
- 입력: 1
- 출력: 2

## 파일 구조
```
anigma-plus-one/
├── main.cpp      # C++ 소스 코드
├── Makefile      # 빌드 및 실행 타겟
└── README.md     # 설명 파일
```

## Makefile 타겟
- `make build`: 소스 코드를 컴파일하여 실행 파일 생성
- `make run INPUT=<파일경로>`: 프로그램 실행 (입력 파일 경로 전달)
- `make clean`: 빌드된 파일 정리

## 로컬 테스트 방법

1. 테스트 입력 파일 생성:
```bash
echo "1" > input.txt
```

2. 빌드:
```bash
make build
```

3. 실행:
```bash
make run INPUT=input.txt
```

4. 예상 출력:
```
2
```

## ZIP 파일 생성 방법

제출을 위해 ZIP 파일을 생성합니다:

```bash
cd /home/tjgus1668/works/ana-online-judge/test/anigma-plus-one
zip -r anigma-plus-one.zip main.cpp Makefile
```

또는 상위 디렉토리에서:

```bash
cd /home/tjgus1668/works/ana-online-judge/test
zip -r anigma-plus-one.zip anigma-plus-one/main.cpp anigma-plus-one/Makefile
```

**중요**: ZIP 파일의 최상위에 `Makefile`과 `main.cpp`가 있어야 합니다.

## 제출 후 채점 과정

1. ZIP 파일 검증 (Makefile 존재 및 build, run 타겟 확인)
2. MinIO에 ZIP 파일 업로드
3. Judge 서버에서 ZIP 파일 다운로드 및 압축 해제
4. `make build` 실행하여 컴파일
5. 각 테스트케이스마다 `make run INPUT=<테스트케이스>` 실행
6. 출력 결과와 예상 출력 비교

